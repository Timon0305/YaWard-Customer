const domain = '46.101.153.203';
// const domain = 'localhost';
export const webUrl = `http://${domain}:5000`;
